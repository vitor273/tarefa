<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit;
}

$arquivo = 'produtos.json';
$produtos = file_exists($arquivo) ? json_decode(file_get_contents($arquivo), true) : [];

function taxaProducao($quantidade, $tempo) {
    return $tempo > 0 ? round($quantidade / $tempo, 2) : 0;
}

function taxaRefugo($refugadas, $quantidade) {
    return $quantidade > 0 ? round(($refugadas / $quantidade) * 100, 2) : 0;
}

// Filtro por data
$data_inicial = $_GET['data_inicial'] ?? '';
$data_final = $_GET['data_final'] ?? '';

$produtos_filtrados = [];

foreach ($produtos as $produto) {
    if (!isset($produto['data'])) continue; // pula se não tiver data

    $data_produto = $produto['data'];

    if (
        ($data_inicial === '' || $data_produto >= $data_inicial) &&
        ($data_final === '' || $data_produto <= $data_final)
    ) {
        $produtos_filtrados[] = $produto;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
    <?php include 'menu.php'?>
<head>
    <meta charset="UTF-8">
    <title>📦 Lista de Produtos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background-color:black; color:white;">
<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>📦 Lista de Produtos</h2>
    </div>

    <!-- Formulário de filtro por data -->
    <form class="row g-3 mb-4" method="GET">
        <div class="col-md-5">
            <label class="form-label">Data Inicial</label>
            <input type="date" name="data_inicial" class="form-control" value="<?= htmlspecialchars($data_inicial) ?>">
        </div>
        <div class="col-md-5">
            <label class="form-label">Data Final</label>
            <input type="date" name="data_final" class="form-control" value="<?= htmlspecialchars($data_final) ?>">
        </div>
        <div class="col-md-2 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100">Filtrar</button>
        </div>
    </form>

    <?php if (empty($produtos_filtrados)): ?>
        <div class="alert alert-warning">Nenhum produto encontrado no período selecionado.</div>
    <?php else: ?>
        <table class="table table-bordered table-striped text-center align-middle table-dark">
            <thead>
                <tr>
                    <th>Produto</th>
                    <th>Produzidas</th>
                    <th>Refugadas</th>
                    <th>Tempo (min)</th>
                    <th>Data</th>
                    <th>Taxa de Produção</th>
                    <th>Taxa de Refugo</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produtos_filtrados as $index => $p): ?>
                    <tr>
                        <td><?= htmlspecialchars($p['nome']) ?></td>
                        <td><?= $p['quantidade'] ?></td>
                        <td><?= $p['refugadas'] ?></td>
                        <td><?= $p['tempo'] ?></td>
                        <td><?= $p['data'] ?></td>
                        <td><?= taxaProducao($p['quantidade'], $p['tempo']) ?> un/min</td>
                        <td><?= taxaRefugo($p['refugadas'], $p['quantidade']) ?>%</td>
                     
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
</body>
</html>